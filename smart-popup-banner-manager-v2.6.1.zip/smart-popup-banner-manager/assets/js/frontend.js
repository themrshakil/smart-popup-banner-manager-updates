(function () {
  'use strict';
  var data = window.SPBM_DATA || {};
  function storageKey(root) { return 'spbm_seen_' + (data.visitorHash || 'visitor') + '_' + root.dataset.popupId; }
  function canUseStorage() {
    try { localStorage.setItem('spbm_t', '1'); localStorage.removeItem('spbm_t'); return true; } catch (e) { return false; }
  }
  var hasStorage = canUseStorage();
  function shouldShow(root) {
    if (data.reset && hasStorage) localStorage.removeItem(storageKey(root));
    if (!hasStorage) return true;
    var last = parseInt(localStorage.getItem(storageKey(root)) || '0', 10);
    var interval = Math.max(0, parseInt(root.dataset.interval || '30', 10)) * 60 * 1000;
    return interval === 0 || Date.now() - last > interval;
  }
  function markSeen(root) { if (hasStorage) localStorage.setItem(storageKey(root), String(Date.now())); }
  function event(root, type) {
    if (!data.analytics) return;
    var body = new URLSearchParams();
    body.append('action', 'spbm_event');
    body.append('nonce', data.nonce || '');
    body.append('popup_id', root.dataset.popupId || '0');
    body.append('event_type', type);
    body.append('page_url', window.location.href);
    fetch(data.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: body.toString() }).catch(function () {});
  }
  function open(root) {
    root.classList.add('spbm-visible');
    root.removeAttribute('aria-hidden');
    markSeen(root);
    event(root, 'view');
    var ac = parseInt(root.dataset.autoClose || '0', 10);
    if (ac > 0) setTimeout(function(){ close(root); }, ac * 1000);
  }
  function close(root) {
    if (!root.classList.contains('spbm-visible')) return;
    root.classList.remove('spbm-visible');
    root.setAttribute('aria-hidden', 'true');
    event(root, 'close');
  }
  function boot() {
    var roots = document.querySelectorAll('.spbm-root');
    if (!roots.length) return;
    roots.forEach(function(root){
      if (!shouldShow(root)) return;
      if (data.reducedMotion && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) root.classList.add('spbm-reduced-motion');
      setTimeout(function(){ open(root); }, Math.max(0, parseInt(root.dataset.delay || '2', 10)) * 1000);
      root.querySelectorAll('[data-spbm-close]').forEach(function(el){ el.addEventListener('click', function(){ close(root); }); });
      root.querySelectorAll('[data-spbm-click]').forEach(function(el){ el.addEventListener('click', function(){ event(root, 'click'); }); });
    });
    document.addEventListener('keydown', function(e){ if(e.key === 'Escape') roots.forEach(close); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
