(function(){'use strict';document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('.spbm-panel input,.spbm-panel select,.spbm-panel textarea').forEach(function(el){el.addEventListener('change',function(){document.body.classList.add('spbm-dirty');});});});})();
(function(){
  function pad(n){ return String(n).padStart(2,'0'); }
  function tick(){
    document.querySelectorAll('.spbm-countdown').forEach(function(box){
      var expiry = parseInt(box.getAttribute('data-expiry') || '0', 10) * 1000;
      var diff = Math.max(0, expiry - Date.now());
      var days = Math.floor(diff / 86400000); diff -= days * 86400000;
      var hours = Math.floor(diff / 3600000); diff -= hours * 3600000;
      var mins = Math.floor(diff / 60000); diff -= mins * 60000;
      var secs = Math.floor(diff / 1000);
      var set = function(sel, val){ var el = box.querySelector(sel); if(el) el.textContent = val; };
      set('[data-days]', days); set('[data-hours]', pad(hours)); set('[data-minutes]', pad(mins)); set('[data-seconds]', pad(secs));
      if (expiry && expiry <= Date.now()) box.classList.add('is-expired');
    });
  }
  tick(); setInterval(tick,1000);
})();
