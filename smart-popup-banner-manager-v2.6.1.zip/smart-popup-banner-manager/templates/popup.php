<?php if (!defined('ABSPATH')) exit; ?>
<div id="spbm-popup-root"
     class="spbm-root spbm-position-<?php echo esc_attr($data['position']); ?> spbm-anim-<?php echo esc_attr($data['animation']); ?>"
     data-popup-id="<?php echo esc_attr($data['id']); ?>"
     data-delay="<?php echo esc_attr($data['delay']); ?>"
     data-interval="<?php echo esc_attr($data['interval']); ?>"
     data-auto-close="<?php echo esc_attr($data['auto_close']); ?>"
     style="--spbm-brand:<?php echo esc_attr($data['brand']); ?>;--spbm-accent:<?php echo esc_attr($data['accent']); ?>;--spbm-max-width:<?php echo esc_attr($data['max_width']); ?>;--spbm-radius:<?php echo esc_attr($data['radius']); ?>;">
    <?php if ($data['overlay']): ?><div class="spbm-overlay" data-spbm-close></div><?php endif; ?>
    <section class="spbm-popup" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr($data['title']); ?>">
        <button type="button" class="spbm-close" data-spbm-close aria-label="Close popup">×</button>
        <div class="spbm-content">
            <?php if ($data['type'] === 'html'): ?>
                <?php echo wp_kses_post($data['html']); ?>
            <?php elseif (!empty($data['image'])): ?>
                <?php if (!empty($data['link'])): ?><a class="spbm-banner-link" href="<?php echo esc_url($data['link']); ?>" data-spbm-click aria-label="<?php echo esc_attr($data['cta_label']); ?>"><?php endif; ?>
                    <img loading="eager" decoding="async" src="<?php echo esc_url($data['image']); ?>" alt="<?php echo esc_attr($data['title']); ?>">
                <?php if (!empty($data['link'])): ?></a><?php endif; ?>
            <?php endif; ?>
        </div>
    </section>
</div>
