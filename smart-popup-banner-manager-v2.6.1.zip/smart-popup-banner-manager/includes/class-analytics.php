<?php
if (!defined('ABSPATH')) exit;

class SPBM_Analytics {
    public function __construct(){
        add_action('wp_ajax_spbm_event',[$this,'event']);
        add_action('wp_ajax_nopriv_spbm_event',[$this,'event']);
        add_action('admin_post_spbm_export_analytics',[$this,'export_csv']);
        add_action('admin_post_spbm_clear_analytics',[$this,'clear']);
    }

    public function event(){
        check_ajax_referer('spbm_event','nonce');
        $s=spbm_get_settings();
        if(!spbm_bool($s['enable_analytics'])) wp_send_json_success(['tracked'=>false]);
        $popup_id=absint($_POST['popup_id']??0);
        $type=sanitize_key($_POST['event_type']??'');
        if(!$popup_id || !in_array($type,['view','close','click'],true)) wp_send_json_error(['message'=>'Invalid event'],400);
        global $wpdb;
        $wpdb->insert($wpdb->prefix.'spbm_events',[
            'popup_id'=>$popup_id,
            'event_type'=>$type,
            'visitor_hash'=>spbm_client_ip_hash(),
            'page_url'=>esc_url_raw($_POST['page_url']??''),
            'created_at'=>current_time('mysql')
        ],['%d','%s','%s','%s','%s']);
        wp_send_json_success(['tracked'=>true]);
    }

    public static function totals($days=30){
        global $wpdb; $table=$wpdb->prefix.'spbm_events'; $days=max(1,absint($days));
        $rows=$wpdb->get_results($wpdb->prepare("SELECT event_type, COUNT(*) total FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY) GROUP BY event_type",$days),ARRAY_A);
        $out=['view'=>0,'click'=>0,'close'=>0];
        foreach((array)$rows as $r){ if(isset($out[$r['event_type']])) $out[$r['event_type']]=(int)$r['total']; }
        $out['ctr']=$out['view']>0 ? round(($out['click']/$out['view'])*100,2) : 0;
        $out['close_rate']=$out['view']>0 ? round(($out['close']/$out['view'])*100,2) : 0;
        return $out;
    }

    public static function campaign_rows($days=30){
        global $wpdb; $table=$wpdb->prefix.'spbm_events'; $days=max(1,absint($days));
        $rows=$wpdb->get_results($wpdb->prepare("SELECT popup_id,
            SUM(CASE WHEN event_type='view' THEN 1 ELSE 0 END) views,
            SUM(CASE WHEN event_type='click' THEN 1 ELSE 0 END) clicks,
            SUM(CASE WHEN event_type='close' THEN 1 ELSE 0 END) closes,
            MAX(created_at) last_event
            FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
            GROUP BY popup_id ORDER BY views DESC LIMIT 100",$days));
        return $rows ?: [];
    }

    public static function daily_rows($days=14){
        global $wpdb; $table=$wpdb->prefix.'spbm_events'; $days=max(1,absint($days));
        return $wpdb->get_results($wpdb->prepare("SELECT DATE(created_at) day,
            SUM(CASE WHEN event_type='view' THEN 1 ELSE 0 END) views,
            SUM(CASE WHEN event_type='click' THEN 1 ELSE 0 END) clicks,
            SUM(CASE WHEN event_type='close' THEN 1 ELSE 0 END) closes
            FROM $table WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
            GROUP BY DATE(created_at) ORDER BY day ASC",$days)) ?: [];
    }

    public function export_csv(){
        if(!current_user_can('manage_options')) wp_die('Permission denied.');
        check_admin_referer('spbm_export_analytics');
        $days=absint($_GET['days']??30) ?: 30;
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=spbm-analytics-'.$days.'-days.csv');
        $out=fopen('php://output','w');
        fputcsv($out,['Campaign ID','Campaign','Views','Clicks','Closes','CTR %','Close Rate %','Last Event']);
        foreach(self::campaign_rows($days) as $r){
            $views=(int)$r->views; $clicks=(int)$r->clicks; $closes=(int)$r->closes;
            fputcsv($out,[$r->popup_id,get_the_title($r->popup_id),$views,$clicks,$closes,$views?round($clicks/$views*100,2):0,$views?round($closes/$views*100,2):0,$r->last_event]);
        }
        fclose($out); exit;
    }

    public function clear(){
        if(!current_user_can('manage_options')) wp_die('Permission denied.');
        check_admin_referer('spbm_clear_analytics');
        global $wpdb; $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}spbm_events");
        wp_safe_redirect(add_query_arg(['page'=>'spbm-analytics','spbm_cleared'=>'1'],admin_url('admin.php'))); exit;
    }
}
