<?php
if (!defined('ABSPATH')) exit;

function spbm_default_settings() {
    return [
        'license_key' => '',
        'license_api_url' => '',
        'license_csv_url' => '', // legacy fallback
        'license_cache_hours' => 12,
        'license_hide_credentials' => '1',
        'license_domain_override' => '',
        'update_json_url' => defined('SPBM_DEFAULT_UPDATE_JSON_URL') ? SPBM_DEFAULT_UPDATE_JSON_URL : '',
        'brand_color' => '#5b3df5',
        'accent_color' => '#111827',
        'default_interval' => 0,
        'enable_analytics' => '1',
        'respect_reduced_motion' => '1',
        'view_details_url' => '',
    ];
}
function spbm_get_settings() { return wp_parse_args(get_option('spbm_settings', []), spbm_default_settings()); }

function spbm_update_json_url() {
    $settings = spbm_get_settings();
    $url = trim((string)($settings['update_json_url'] ?? ''));
    if ($url !== '') return esc_url_raw($url);
    return defined('SPBM_DEFAULT_UPDATE_JSON_URL') ? esc_url_raw(SPBM_DEFAULT_UPDATE_JSON_URL) : '';
}
function spbm_current_domain() { return spbm_normalize_domain(parse_url(home_url(), PHP_URL_HOST)); }
function spbm_license_domain() {
    $settings = spbm_get_settings();
    $override = spbm_normalize_domain($settings['license_domain_override'] ?? '');
    return $override ?: spbm_current_domain();
}
function spbm_domain_candidates() {
    $candidates = [];
    $add = function($d) use (&$candidates) {
        $n = spbm_normalize_domain($d);
        if ($n && !in_array($n, $candidates, true)) $candidates[] = $n;
    };
    $settings = spbm_get_settings();
    $add($settings['license_domain_override'] ?? '');
    $add(parse_url(home_url(), PHP_URL_HOST));
    $add(parse_url(site_url(), PHP_URL_HOST));
    if (!empty($_SERVER['HTTP_HOST'])) $add(wp_unslash($_SERVER['HTTP_HOST']));
    if (!empty($_SERVER['SERVER_NAME'])) $add(wp_unslash($_SERVER['SERVER_NAME']));
    return $candidates ?: [spbm_current_domain()];
}
function spbm_normalize_domain($domain) {
    $domain = strtolower(trim((string)$domain));
    $domain = preg_replace('#^https?://#', '', $domain);
    $domain = preg_replace('/^www\./', '', $domain);
    $domain = strtok($domain, '/');
    return sanitize_text_field(trim((string)$domain));
}
function spbm_bool($value) { return in_array($value, ['1', 1, true, 'true', 'yes', 'on'], true); }
function spbm_csv_row_get($row, $key, $map) { return isset($map[$key], $row[$map[$key]]) ? trim((string)$row[$map[$key]]) : ''; }
function spbm_mask_key($key) {
    $key = (string) $key;
    if (strlen($key) <= 8) return str_repeat('•', max(0, strlen($key)));
    return substr($key, 0, 4) . str_repeat('•', max(4, strlen($key)-8)) . substr($key, -4);
}
function spbm_parse_expiry_timestamp($expiry) {
    $expiry = trim((string)$expiry);
    if ($expiry === '') return 0;
    try {
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiry)) {
            $tz = wp_timezone();
            $dt = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $expiry . ' 23:59:59', $tz);
            return $dt ? $dt->getTimestamp() : 0;
        }
        $ts = strtotime($expiry);
        if (!$ts) return 0;
        // If Apps Script returns midnight ISO, treat it as an inclusive date license.
        if (preg_match('/T00:00:00/', $expiry) || preg_match('/T18:00:00\.000Z$/', $expiry)) {
            $date = gmdate('Y-m-d', $ts);
            $dt = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $date . ' 23:59:59', wp_timezone());
            return $dt ? $dt->getTimestamp() : $ts;
        }
        return $ts;
    } catch (Exception $e) { return 0; }
}
function spbm_client_ip_hash() {
    $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    $ip = '';
    foreach ($keys as $key) {
        if (!empty($_SERVER[$key])) { $ip = explode(',', sanitize_text_field(wp_unslash($_SERVER[$key])))[0]; break; }
    }
    return $ip ? hash_hmac('sha256', trim($ip), wp_salt('auth')) : '';
}
function spbm_positions() {
    return [
        'center' => 'Center modal', 'top-center' => 'Top center', 'bottom-center' => 'Bottom center',
        'top-right' => 'Top right', 'top-left' => 'Top left', 'bottom-right' => 'Bottom right', 'bottom-left' => 'Bottom left',
        'left-middle' => 'Left middle', 'right-middle' => 'Right middle', 'top-bar' => 'Top full-width bar', 'bottom-bar' => 'Bottom full-width bar',
        'slide-in-right' => 'Slide-in right', 'slide-in-left' => 'Slide-in left', 'corner-card' => 'Modern corner card',
        'glass-center' => 'Glass center', 'command-palette' => 'Command palette style', 'mobile-sheet' => 'Mobile bottom sheet'
    ];
}
function spbm_format_expiry_date($expiry) {
    $ts = spbm_parse_expiry_timestamp($expiry);
    return $ts ? wp_date('Y-m-d', $ts) : sanitize_text_field((string)$expiry);
}

function spbm_visitor_hash() {
    $ip_keys = ['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR'];
    $ip = '';
    foreach ($ip_keys as $key) {
        if (!empty($_SERVER[$key])) { $ip = trim(explode(',', (string) $_SERVER[$key])[0]); break; }
    }
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 160) : '';
    return substr(hash_hmac('sha256', $ip . '|' . $ua, wp_salt('auth')), 0, 16);
}

function spbm_installation_id() {
    $id = get_option('spbm_installation_id');
    if (!$id) {
        $id = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : md5(home_url().'|'.wp_salt('auth').'|'.microtime(true));
        add_option('spbm_installation_id', $id, '', false);
    }
    return sanitize_text_field($id);
}
