<?php
if (!defined('ABSPATH')) exit;

class SPBM_Frontend {
    private $license;

    public function __construct($license) {
        $this->license = $license;
        add_action('wp_enqueue_scripts', [$this, 'assets']);
        add_action('wp_footer', [$this, 'render'], 40);
        add_shortcode('spbm_popup', [$this, 'shortcode']);
    }

    public function assets() {
        $s = spbm_get_settings();
        wp_enqueue_style('spbm-inter', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap', [], null);
        wp_enqueue_style('spbm-frontend', SPBM_URL . 'assets/css/frontend.css', [], SPBM_VERSION);
        wp_enqueue_script('spbm-frontend', SPBM_URL . 'assets/js/frontend.js', [], SPBM_VERSION, true);
        wp_localize_script('spbm-frontend', 'SPBM_DATA', [
            'ajaxUrl'       => admin_url('admin-ajax.php'),
            'nonce'         => wp_create_nonce('spbm_event'),
            'analytics'     => spbm_bool($s['enable_analytics']),
            'reducedMotion' => spbm_bool($s['respect_reduced_motion']),
            'visitorHash'   => spbm_visitor_hash(),
            'debug'         => current_user_can('manage_options') && isset($_GET['spbm_debug']),
            'reset'         => isset($_GET['spbm_reset']),
        ]);
    }

    public function shortcode($atts = []) {
        $atts = shortcode_atts(['id' => 0, 'debug' => 0], $atts, 'spbm_popup');
        return $this->render_to_string(absint($atts['id']), spbm_bool($atts['debug']));
    }

    public function render() {
        echo $this->render_to_string(0, current_user_can('manage_options') && isset($_GET['spbm_debug']));
    }

    private function render_to_string($specific_id = 0, $debug = false) {
        $license_status = $this->license->get_status(false);
        if (empty($license_status['valid'])) {
            return $this->debug_comment('license_not_valid', $license_status, $debug);
        }

        $popup = $specific_id ? get_post($specific_id) : $this->get_popup($debug);
        if (!$popup || $popup->post_type !== 'spbm_popup' || $popup->post_status !== 'publish') {
            return $this->debug_comment('no_matching_published_popup', ['specific_id' => $specific_id], $debug);
        }

        if (!$specific_id && !$this->matches($popup, $debug)) {
            return $this->debug_comment('popup_did_not_match_rules', ['popup_id' => $popup->ID], $debug);
        }

        $data = $this->popup_data($popup);
        if ($data['type'] !== 'html' && empty($data['image'])) {
            return $this->debug_comment('image_popup_has_no_image_url', ['popup_id' => $popup->ID], $debug);
        }
        if ($data['type'] === 'html' && trim((string)$data['html']) === '') {
            return $this->debug_comment('html_popup_has_empty_template', ['popup_id' => $popup->ID], $debug);
        }

        ob_start();
        include SPBM_PATH . 'templates/popup.php';
        $html = ob_get_clean();
        if ($debug) $html = "\n<!-- SPBM DEBUG: rendering popup #" . esc_html($popup->ID) . " -->\n" . $html;
        return $html;
    }

    private function debug_comment($reason, $context = [], $debug = false) {
        if (!$debug) return '';
        $safe = wp_json_encode($context);
        return "\n<!-- SPBM DEBUG: " . esc_html($reason) . " | " . esc_html($safe) . " -->\n";
    }

    private function get_popup($debug = false) {
        $q = new WP_Query([
            'post_type'      => 'spbm_popup',
            'post_status'    => 'publish',
            'posts_per_page' => 50,
            'no_found_rows'  => true,
            'meta_query'     => [[
                'key'     => '_spbm_active',
                'value'   => '1',
                'compare' => '=',
            ]],
        ]);

        $items = [];
        foreach ($q->posts as $p) {
            if (!$this->matches($p, $debug)) continue;
            $items[] = [
                'post'     => $p,
                'priority' => absint(get_post_meta($p->ID, '_spbm_priority', true) ?: 10),
            ];
        }
        if (!$items) return null;
        usort($items, function($a, $b) {
            if ($a['priority'] === $b['priority']) return $b['post']->ID <=> $a['post']->ID;
            return $a['priority'] <=> $b['priority'];
        });
        return $items[0]['post'];
    }

    private function matches($p, $debug = false) {
        $device = get_post_meta($p->ID, '_spbm_device', true) ?: 'all';
        if ($device !== 'all' && $device !== (wp_is_mobile() ? 'mobile' : 'desktop')) return false;

        $now = current_time('timestamp');
        $start = trim((string)get_post_meta($p->ID, '_spbm_start_at', true));
        $end = trim((string)get_post_meta($p->ID, '_spbm_end_at', true));
        if ($start && strtotime($start) && strtotime($start) > $now) return false;
        if ($end && strtotime($end) && strtotime($end) < $now) return false;

        $pages = trim((string)get_post_meta($p->ID, '_spbm_pages', true));
        if ($pages !== '' && strtolower($pages) !== 'all') {
            $path = '/' . ltrim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
            $ok = false;
            foreach (array_map('trim', explode(',', $pages)) as $rule) {
                if ($rule === '') continue;
                if ($rule === 'all') { $ok = true; break; }
                if ($rule === 'homepage' && is_front_page()) { $ok = true; break; }
                $rule_path = '/' . ltrim($rule, '/');
                if (stripos($path, $rule_path) === 0) { $ok = true; break; }
            }
            if (!$ok) return false;
        }

        // WooCommerce targeting is applied only when Page Rules is not set to all.
        // This prevents a common setup issue: Page Rules=all + WooCommerce Pages filled should still show site-wide.
        $page_rules_are_all = ($pages === '' || strtolower($pages) === 'all');
        $wc = trim((string)get_post_meta($p->ID, '_spbm_wc_pages', true));
        if (!$page_rules_are_all && $wc !== '') {
            if (!function_exists('is_woocommerce')) return false;
            $rules = array_map('trim', explode(',', strtolower($wc)));
            $ok = false;
            if (in_array('shop', $rules, true) && function_exists('is_shop') && is_shop()) $ok = true;
            if (in_array('product', $rules, true) && function_exists('is_product') && is_product()) $ok = true;
            if (in_array('cart', $rules, true) && function_exists('is_cart') && is_cart()) $ok = true;
            if (in_array('checkout', $rules, true) && function_exists('is_checkout') && is_checkout()) $ok = true;
            if (!$ok) return false;
        }
        return true;
    }

    private function popup_data($p) {
        $m = function($k, $d = '') use ($p) {
            $v = get_post_meta($p->ID, '_spbm_' . $k, true);
            return $v !== '' ? $v : $d;
        };
        $s = spbm_get_settings();
        return [
            'id'         => $p->ID,
            'title'      => get_the_title($p),
            'type'       => $m('type', 'image'),
            'image'      => $m('image'),
            'link'       => $this->link_with_utm($m('link'), $m('utm_source', 'spbm'), $p->ID),
            'html'       => $m('html'),
            'position'   => $m('position', 'center'),
            'delay'      => absint($m('delay', 2)),
            'auto_close' => absint($m('auto_close', 0)),
            'interval'   => absint($m('interval', $s['default_interval'])),
            'overlay'    => spbm_bool($m('overlay', '1')),
            'max_width'  => $m('max_width', '640px'),
            'radius'     => $m('radius', '22px'),
            'animation'  => $m('animation', 'fade-scale'),
            'cta_label'  => $m('cta_label', 'Open offer'),
            'brand'      => $s['brand_color'],
            'accent'     => $s['accent_color'],
        ];
    }

    private function link_with_utm($url, $source, $id) {
        if (!$url) return '';
        return add_query_arg([
            'utm_source'   => sanitize_key($source),
            'utm_medium'   => 'popup',
            'utm_campaign' => 'spbm_' . absint($id),
        ], esc_url_raw($url));
    }
}
