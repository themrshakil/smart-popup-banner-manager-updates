<?php
if (!defined('ABSPATH')) exit;
final class SPBM_Plugin {
    private static $instance = null;
    public $license;
    public static function instance() { return self::$instance ?: self::$instance = new self(); }
    private function __construct() { add_action('plugins_loaded', [$this, 'init']); }
    public function init() {
        new SPBM_Popup_Post_Type();
        $this->license = new SPBM_License();
        new SPBM_Admin($this->license);
        new SPBM_Frontend($this->license);
        new SPBM_Analytics();
        new SPBM_Update_Checker($this->license);
    }
    public static function activate() {
        if (!get_option('spbm_settings')) add_option('spbm_settings', spbm_default_settings());
        global $wpdb;
        $table = $wpdb->prefix . 'spbm_events';
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta("CREATE TABLE $table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            popup_id bigint(20) unsigned NOT NULL DEFAULT 0,
            event_type varchar(32) NOT NULL DEFAULT '',
            visitor_hash varchar(64) NOT NULL DEFAULT '',
            page_url text NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id), KEY popup_event (popup_id,event_type), KEY created_at (created_at)
        ) $charset;");
        delete_transient('spbm_license_cache');
        flush_rewrite_rules();
    }
    public static function deactivate() { flush_rewrite_rules(); }
}
