<?php
if (!defined('ABSPATH')) exit;

class SPBM_License {
    public function is_valid() { $s = $this->get_status(false); return !empty($s['valid']); }

    public function get_status($force = false) {
        if (!$force) {
            $cached = get_transient('spbm_license_cache');
            if (is_array($cached) && !empty($cached['valid'])) return $cached;
            if (is_array($cached) && empty($cached['valid'])) delete_transient('spbm_license_cache');
        } else {
            delete_transient('spbm_license_cache');
        }

        $settings = spbm_get_settings();
        $domain = spbm_license_domain();
        $result = [
            'valid'=>false,
            'status'=>'not_configured',
            'message'=>'License is not configured.',
            'expires'=>'',
            'plan'=>'',
            'checked_at'=>current_time('mysql'),
            'domain'=>$domain,
            'expires_ts'=>0,
            'source'=>'none',
            'http_code'=>'',
            'raw_status'=>'',
            'debug'=>'',
        ];

        $api = trim((string)($settings['license_api_url'] ?: ($settings['license_csv_url'] ?? '')), " \t\n\r\0\x0B\"'");
        $key = trim((string)($settings['license_key'] ?? ''), " \t\n\r\0\x0B\"'");
        if ($api === '' || $key === '') return $this->no_cache($result);

        // Never allow /dev Apps Script URLs for client activation. /exec is the deployed web app URL.
        if (preg_match('#/dev(?:$|\?)#', $api)) {
            return $this->no_cache(array_merge($result, [
                'status'=>'dev_url',
                'message'=>'Use the deployed Apps Script /exec URL, not /dev.',
                'source'=>'apps_script',
            ]));
        }

        $last_evaluated = null;
        $last_error = null;
        foreach (spbm_domain_candidates() as $try_domain) {
            $request_url = $this->build_request_url($api, [
                'action' => 'check',
                // Send multiple names so old/new Apps Script deployments can read the same request.
                'domain' => $try_domain,
                'licensed_domain' => $try_domain,
                'host' => $try_domain,
                'key' => $key,
                'license_key' => $key,
                'k' => $key,
                'site' => home_url(),
                'home_url' => home_url(),
                'v' => SPBM_VERSION,
                'version' => SPBM_VERSION,
                'activation_id' => spbm_installation_id(),
                'installation_id' => spbm_installation_id(),
                't' => time(),
            ]);

            $response = $this->remote_get($request_url, true);
            if (is_wp_error($response)) {
                $response = $this->remote_get($request_url, false);
            }

            if (is_wp_error($response)) {
                $last_error = $response;
                continue;
            }

            $code = (int) wp_remote_retrieve_response_code($response);
            $body = trim((string) wp_remote_retrieve_body($response));
            if ($code < 200 || $code >= 300 || $body === '') {
                $last_evaluated = $this->no_cache(array_merge($result,[
                    'status'=>'bad_response',
                    'message'=>'License API returned an invalid response. HTTP '.$code.'.',
                    'http_code'=>$code,
                    'source'=>'api',
                    'debug'=>substr(wp_strip_all_tags($body), 0, 300),
                    'domain'=>$try_domain,
                ]));
                continue;
            }

            $json = json_decode($body, true);
            if (is_array($json) && isset($json['status'])) {
                $evaluated = $this->evaluate_api_result($json, $try_domain);
                $evaluated['http_code'] = $code;
                $evaluated['source'] = 'apps_script';
                $evaluated['debug'] = substr($body, 0, 500);
                if (!empty($evaluated['valid'])) return $evaluated;
                $last_evaluated = $evaluated;
                // Continue trying only for match-related failures. Stop for blocked/expired/invalid_expiry.
                if (!in_array($evaluated['status'], ['not_found','domain_mismatch','missing_params'], true)) return $evaluated;
                continue;
            }

            $evaluated = $this->evaluate_csv_result($body, $try_domain, $key);
            $evaluated['http_code'] = $code;
            $evaluated['source'] = 'csv';
            $evaluated['debug'] = substr($body, 0, 500);
            if (!empty($evaluated['valid'])) return $evaluated;
            $last_evaluated = $evaluated;
        }

        if ($last_evaluated) return $last_evaluated;
        if ($last_error) {
            return $this->no_cache(array_merge($result,[
                'status'=>'connection_error',
                'message'=>'Could not connect to license API: '.$last_error->get_error_message(),
                'source'=>'api',
                'debug'=>$api,
            ]));
        }
        return $this->no_cache(array_merge($result,['status'=>'not_found','message'=>'No matching license was found for this domain/key.']));
    }

    private function remote_get($url, $sslverify = true) {
        return wp_remote_get($url, [
            'timeout'=>25,
            'redirection'=>10,
            'sslverify'=>$sslverify,
            'user-agent'=>'SPBM/'.SPBM_VERSION.'; '.home_url(),
            'headers'=>[
                'Accept'=>'application/json,text/csv,text/plain,*/*',
                'Cache-Control'=>'no-cache, no-store, max-age=0',
                'Pragma'=>'no-cache',
            ],
        ]);
    }

    private function build_request_url($api, $args) {
        $api = esc_url_raw($api);
        return add_query_arg($args, $api);
    }

    private function evaluate_api_result($data, $domain_override = null) {
        $status = strtolower(trim(sanitize_text_field($data['status'] ?? 'invalid')));
        $status = str_replace([' ', '-'], '_', $status);
        $expiry = sanitize_text_field($data['expiry'] ?? ($data['expires'] ?? ''));
        $plan = sanitize_text_field($data['plan'] ?? '');
        $message = sanitize_text_field($data['message'] ?? '');
        $expires_ts = spbm_parse_expiry_timestamp($expiry);
        $common = [
            'expires'=>$expiry,
            'expires_ts'=>$expires_ts,
            'plan'=>$plan,
            'checked_at'=>current_time('mysql'),
            'domain'=>$domain_override ?: spbm_license_domain(),
            'raw_status'=>$status,
        ];

        if ($status !== 'active') {
            $messages = [
                'not_found' => 'No matching license key was found in your private license sheet.',
                'domain_mismatch' => 'This license key is not assigned to this domain.',
                'already_used' => 'This license is already activated on another website.',
                'blocked' => 'This license is blocked remotely.',
                'inactive' => 'License is not active.',
                'missing_params' => 'License API did not receive domain/key correctly.',
                'config_error' => 'License API configuration error. Check Sheet tab/columns and redeploy Apps Script.',
                'empty_source' => 'License sheet has no rows.',
                'dev_url' => 'Use the Apps Script /exec URL, not /dev.',
            ];
            return $this->no_cache(array_merge($common,[
                'valid'=>false,
                'status'=>$status ?: 'inactive',
                'message'=>$message ?: ($messages[$status] ?? 'License is not active.'),
            ]));
        }

        if (!$expires_ts) {
            return $this->no_cache(array_merge($common,['valid'=>false,'status'=>'invalid_expiry','message'=>'License expiry date is missing or invalid. Use YYYY-MM-DD.']));
        }
        if ($expires_ts < current_time('timestamp')) {
            return $this->no_cache(array_merge($common,['valid'=>false,'status'=>'expired','message'=>'License has expired.']));
        }
        return $this->cache(array_merge($common,['valid'=>true,'status'=>'active','message'=>$message ?: 'License is active.']));
    }

    private function evaluate_csv_result($body, $domain, $key) {
        $result = ['valid'=>false,'status'=>'invalid','message'=>'Invalid license source.','expires'=>'','expires_ts'=>0,'plan'=>'','checked_at'=>current_time('mysql'),'domain'=>$domain];
        $rows = array_map('str_getcsv', preg_split('/\r\n|\r|\n/', trim($body)));
        if (count($rows) < 2) return $this->no_cache(array_merge($result,['status'=>'empty_source','message'=>'License source has no rows.']));
        $headers = array_map(fn($h)=>strtolower(trim($h)), array_shift($rows)); $map = array_flip($headers);
        foreach ($rows as $row) {
            $row_domain = spbm_normalize_domain(spbm_csv_row_get($row,'domain',$map));
            $row_key = spbm_csv_row_get($row,'licensekey',$map) ?: spbm_csv_row_get($row,'license_key',$map);
            if ($row_domain !== $domain || trim($row_key) !== $key) continue;
            return $this->evaluate_api_result(['status'=>spbm_csv_row_get($row,'status',$map),'expiry'=>spbm_csv_row_get($row,'expiry',$map),'plan'=>spbm_csv_row_get($row,'plan',$map)]);
        }
        return $this->no_cache(array_merge($result,['status'=>'not_found','message'=>'No matching license was found for this domain/key.']));
    }

    public function deactivate_local() { $this->release_remote_activation(); $this->reset_local(); }

    public function release_remote_activation() {
        $s = spbm_get_settings();
        $api = trim((string)($s['license_api_url'] ?: ($s['license_csv_url'] ?? '')), " \t\n\r\0\x0B\"'");
        $key = trim((string)($s['license_key'] ?? ''), " \t\n\r\0\x0B\"'");
        if ($api === '' || $key === '' || preg_match('#/dev(?:$|\?)#', $api)) return false;
        $url = $this->build_request_url($api, ['action'=>'deactivate','domain'=>spbm_license_domain(),'licensed_domain'=>spbm_license_domain(),'key'=>$key,'license_key'=>$key,'site'=>home_url(),'v'=>SPBM_VERSION,'version'=>SPBM_VERSION,'activation_id'=>spbm_installation_id(),'installation_id'=>spbm_installation_id(),'t'=>time()]);
        $response = $this->remote_get($url, true);
        if (is_wp_error($response)) $response = $this->remote_get($url, false);
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) >= 200 && wp_remote_retrieve_response_code($response) < 300;
    }

    public function reset_local() {
        delete_transient('spbm_license_cache');
        $s = spbm_get_settings();
        $s['license_key'] = '';
        $s['license_api_url'] = '';
        $s['license_csv_url'] = '';
        $s['license_domain_override'] = '';
        update_option('spbm_settings', $s, false);
    }

    private function no_cache($result) { delete_transient('spbm_license_cache'); return $result; }

    private function cache($result, $hours = null) {
        if (empty($result['valid'])) { delete_transient('spbm_license_cache'); return $result; }
        $settings=spbm_get_settings();
        $ttl = HOUR_IN_SECONDS * max(1, absint($hours ?: $settings['license_cache_hours']));
        set_transient('spbm_license_cache',$result,$ttl);
        return $result;
    }
}
