<?php
if (!defined('ABSPATH')) exit;
class SPBM_Popup_Post_Type {
    private $meta_keys = ['active','type','image','link','html','position','priority','delay','auto_close','interval','overlay','device','pages','wc_pages','start_at','end_at','max_width','radius','animation','cta_label','utm_source'];
    public function __construct() {
        add_action('init', [$this, 'register']);
        add_action('add_meta_boxes', [$this, 'boxes']);
        add_action('save_post_spbm_popup', [$this, 'save'], 10, 2);
        add_filter('manage_spbm_popup_posts_columns', [$this, 'columns']);
        add_action('manage_spbm_popup_posts_custom_column', [$this, 'column_content'], 10, 2);
    }
    public function register() {
        register_post_type('spbm_popup', [
            'labels' => ['name'=>'Smart Popups','singular_name'=>'Smart Popup','add_new_item'=>'Add New Popup','edit_item'=>'Edit Popup'],
            'public'=>false,'show_ui'=>true,'show_in_menu'=>'spbm-settings','supports'=>['title'],'menu_icon'=>'dashicons-megaphone',
            'capability_type'=>'post','map_meta_cap'=>true
        ]);
    }
    public function boxes() { add_meta_box('spbm_campaign','Campaign Builder',[$this,'box_html'],'spbm_popup','normal','high'); }
    public function box_html($post) {
        wp_nonce_field('spbm_save_popup','spbm_nonce');
        $m = fn($k,$d='') => get_post_meta($post->ID, '_spbm_'.$k, true) !== '' ? get_post_meta($post->ID, '_spbm_'.$k, true) : $d;
        $positions = spbm_positions(); ?>
        <div class="spbm-panel">
            <p class="spbm-auto-note"><strong>Auto-ready defaults:</strong> New popups are active, site-wide, all devices, no schedule lock, no WooCommerce-only lock, 0-second delay, and 0-minute frequency for instant testing.</p>
            <div class="spbm-grid">
                <label><span>Active</span><select name="spbm_active"><option value="1" <?php selected($m('active','1'),'1');?>>Active</option><option value="0" <?php selected($m('active'),'0');?>>Inactive</option></select></label>
                <label><span>Content Type</span><select name="spbm_type"><option value="image" <?php selected($m('type','image'),'image');?>>Image Banner</option><option value="html" <?php selected($m('type'),'html');?>>HTML Template</option></select></label>
                <label><span>Position</span><select name="spbm_position"><?php foreach($positions as $key=>$label) echo '<option value="'.esc_attr($key).'" '.selected($m('position','center'),$key,false).'>'.esc_html($label).'</option>'; ?></select></label>
                <label><span>Priority</span><input type="number" name="spbm_priority" value="<?php echo esc_attr($m('priority','10'));?>"><small>Lower number shows first.</small></label>
                <label><span>Delay Seconds</span><input type="number" name="spbm_delay" value="<?php echo esc_attr($m('delay','0'));?>"></label>
                <label><span>Auto Close Seconds</span><input type="number" name="spbm_auto_close" value="<?php echo esc_attr($m('auto_close','0'));?>"><small>0 means disabled.</small></label>
                <label><span>Frequency Minutes</span><input type="number" name="spbm_interval" value="<?php echo esc_attr($m('interval','0'));?>"></label>
                <label><span>Overlay</span><select name="spbm_overlay"><option value="1" <?php selected($m('overlay','1'),'1');?>>On</option><option value="0" <?php selected($m('overlay'),'0');?>>Off</option></select></label>
                <label><span>Device</span><select name="spbm_device"><option value="all" <?php selected($m('device','all'),'all');?>>All</option><option value="desktop" <?php selected($m('device'),'desktop');?>>Desktop</option><option value="mobile" <?php selected($m('device'),'mobile');?>>Mobile</option></select></label>
                <label><span>Max Width</span><input type="text" name="spbm_max_width" value="<?php echo esc_attr($m('max_width','640px'));?>" placeholder="640px, 90vw"></label>
                <label><span>Border Radius</span><input type="text" name="spbm_radius" value="<?php echo esc_attr($m('radius','22px'));?>"></label>
                <label><span>Animation</span><select name="spbm_animation"><option value="fade-scale" <?php selected($m('animation','fade-scale'),'fade-scale');?>>Fade Scale</option><option value="slide-up" <?php selected($m('animation'),'slide-up');?>>Slide Up</option><option value="none" <?php selected($m('animation'),'none');?>>None</option></select></label>
            </div>
            <p><label><strong>Image URL</strong><input class="widefat" type="url" name="spbm_image" value="<?php echo esc_attr($m('image'));?>" placeholder="https://..."></label></p>
            <p><label><strong>Click URL</strong><input class="widefat" type="url" name="spbm_link" value="<?php echo esc_attr($m('link'));?>" placeholder="https://..."></label></p>
            <p><label><strong>CTA Label / ARIA Label</strong><input class="widefat" type="text" name="spbm_cta_label" value="<?php echo esc_attr($m('cta_label','Open offer'));?>"></label></p>
            <p><label><strong>Custom HTML Template</strong><textarea class="widefat code" rows="10" name="spbm_html" placeholder="Use clean HTML. Scripts are removed for security."><?php echo esc_textarea($m('html'));?></textarea></label></p>
            <hr><h3>Targeting & Scheduling</h3>
            <p><label><strong>Page Rules</strong><input class="widefat" type="text" name="spbm_pages" value="<?php echo esc_attr($m('pages','all'));?>" placeholder="all OR /shop,/product/sample"></label><small>Use all, homepage, or comma-separated URL paths.</small></p>
            <p><label><strong>WooCommerce Pages</strong><input class="widefat" type="text" name="spbm_wc_pages" value="<?php echo esc_attr($m('wc_pages'));?>" placeholder="shop,product,cart,checkout"></label></p>
            <div class="spbm-grid"><label><span>Start Date/Time</span><input type="datetime-local" name="spbm_start_at" value="<?php echo esc_attr($m('start_at'));?>"></label><label><span>End Date/Time</span><input type="datetime-local" name="spbm_end_at" value="<?php echo esc_attr($m('end_at'));?>"></label></div>
            <p><label><strong>UTM Source</strong><input class="widefat" type="text" name="spbm_utm_source" value="<?php echo esc_attr($m('utm_source','spbm'));?>"></label></p>
        </div><?php
    }
    public function save($post_id, $post) {
        if (!isset($_POST['spbm_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['spbm_nonce'])), 'spbm_save_popup')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;
        $sanitize = [
            'active'=>'sanitize_text_field','type'=>'sanitize_text_field','image'=>'esc_url_raw','link'=>'esc_url_raw','html'=>'wp_kses_post','position'=>'sanitize_text_field','priority'=>'absint','delay'=>'absint','auto_close'=>'absint','interval'=>'absint','overlay'=>'sanitize_text_field','device'=>'sanitize_text_field','pages'=>'sanitize_text_field','wc_pages'=>'sanitize_text_field','start_at'=>'sanitize_text_field','end_at'=>'sanitize_text_field','max_width'=>'sanitize_text_field','radius'=>'sanitize_text_field','animation'=>'sanitize_text_field','cta_label'=>'sanitize_text_field','utm_source'=>'sanitize_key'
        ];
        $defaults = [
            'active'=>'1','type'=>'image','position'=>'center','priority'=>'10','delay'=>'0','auto_close'=>'0','interval'=>'0','overlay'=>'1','device'=>'all','pages'=>'all','wc_pages'=>'','start_at'=>'','end_at'=>'','max_width'=>'640px','radius'=>'22px','animation'=>'fade-scale','cta_label'=>'Open offer','utm_source'=>'spbm'
        ];
        foreach ($sanitize as $key=>$fn) {
            $field = 'spbm_'.$key;
            $value = isset($_POST[$field]) ? wp_unslash($_POST[$field]) : '';
            if (($value === '' || $value === null) && array_key_exists($key, $defaults)) $value = $defaults[$key];
            update_post_meta($post_id, '_spbm_'.$key, call_user_func($fn, $value));
        }
    }
    public function columns($cols) { return ['cb'=>$cols['cb'],'title'=>'Popup','spbm_status'=>'Status','spbm_position'=>'Position','spbm_priority'=>'Priority','date'=>$cols['date']]; }
    public function column_content($col,$post_id) { if($col==='spbm_status') echo get_post_meta($post_id,'_spbm_active',true)==='1'?'Active':'Inactive'; if($col==='spbm_position') echo esc_html(get_post_meta($post_id,'_spbm_position',true)); if($col==='spbm_priority') echo esc_html(get_post_meta($post_id,'_spbm_priority',true)); }
}
