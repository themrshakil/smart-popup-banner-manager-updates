=== Smart Popup Banner Manager ===
Contributors: M.R Shakil
Tags: popup, banner, woocommerce, campaign, license
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.5.0
License: GPLv2 or later

Modern popup banner and HTML campaign manager for WordPress/WooCommerce.

== Features ==
* Image banner and safe HTML template campaigns
* Advanced positions, animations, overlay, schedule and priority
* Page path and WooCommerce page targeting
* Frequency control using browser storage, default 30 minutes
* Private Google Apps Script license API control: active, blocked, expired, renewed
* Custom private update checker with View details support
* Local analytics for view, click and close events
* Inter font and responsive modern UI

== Google Sheet Columns ==
Domain,LicenseKey,Status,Expiry,Plan,Notes
example.com,ABC-123,active,2027-06-11,yearly,First client

== Update JSON Example ==
{"version":"1.1.1","download_url":"https://example.com/smart-popup-banner-manager.zip","requires":"6.0","tested":"6.8","changelog":"Bug fixes."}
