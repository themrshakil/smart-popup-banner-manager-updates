<?php
/**
 * Plugin Name: Smart Popup Banner Manager
 * Plugin URI: https://www.linkedin.com/in/mrshakilinfo
 * Description: Modern popup banner and HTML campaign manager for WordPress/WooCommerce with Google Sheets license control and private update delivery.
 * Version: 2.6.1
 * Author: M.R Shakil
 * Author URI: https://www.linkedin.com/in/mrshakilinfo
 * Text Domain: smart-popup-banner-manager
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) exit;

define('SPBM_VERSION', '2.6.1');
define('SPBM_DEFAULT_UPDATE_JSON_URL', 'https://raw.githubusercontent.com/themrshakil/smart-popup-banner-manager-updates/main/update.json');
define('SPBM_FILE', __FILE__);
define('SPBM_PATH', plugin_dir_path(__FILE__));
define('SPBM_URL', plugin_dir_url(__FILE__));
define('SPBM_BASENAME', plugin_basename(__FILE__));
define('SPBM_SLUG', 'smart-popup-banner-manager');
define('SPBM_PLUGIN_NAME', 'Smart Popup Banner Manager');
define('SPBM_AUTHOR_NAME', 'M.R Shakil');
define('SPBM_AUTHOR_URL', 'https://www.linkedin.com/in/mrshakilinfo');

$spbm_files = [
    'includes/helpers.php',
    'includes/class-plugin.php',
    'includes/class-popup-post-type.php',
    'includes/class-license.php',
    'includes/class-admin.php',
    'includes/class-frontend.php',
    'includes/class-analytics.php',
    'includes/class-update-checker.php',
];
foreach ($spbm_files as $spbm_file) require_once SPBM_PATH . $spbm_file;

function spbm_run_plugin() { return SPBM_Plugin::instance(); }
spbm_run_plugin();

register_activation_hook(__FILE__, ['SPBM_Plugin', 'activate']);
register_deactivation_hook(__FILE__, ['SPBM_Plugin', 'deactivate']);
