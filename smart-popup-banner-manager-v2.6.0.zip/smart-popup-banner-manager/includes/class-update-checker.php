<?php
if (!defined('ABSPATH')) exit;

class SPBM_Update_Checker {
    private $license;

    public function __construct($license, $register_hooks = true){
        $this->license=$license;
        if($register_hooks){
            add_filter('pre_set_site_transient_update_plugins',[$this,'check']);
            add_filter('plugins_api',[$this,'info'],10,3);
            add_action('upgrader_process_complete',[$this,'clear_cache'],10,2);
        }
    }

    public function clear_cache(){ delete_transient('spbm_update_info'); }

    public function fetch_update_info($force=false){
        $s=spbm_get_settings();
        if(empty($s['update_json_url'])) return [];
        if(!$force){ $cached=get_transient('spbm_update_info'); if(is_array($cached)) return $cached; }
        $url=esc_url_raw(trim((string)$s['update_json_url']));
        $res=wp_remote_get($url,['timeout'=>15,'redirection'=>5,'headers'=>['Accept'=>'application/json']]);
        if(is_wp_error($res)) return ['error'=>$res->get_error_message()];
        $code=wp_remote_retrieve_response_code($res);
        $body=wp_remote_retrieve_body($res);
        $data=json_decode($body,true);
        if($code<200 || $code>=300 || !is_array($data)) return ['error'=>'Invalid update JSON response','http_code'=>$code];
        $clean=[
            'version'=>sanitize_text_field($data['version'] ?? ''),
            'download_url'=>esc_url_raw($data['download_url'] ?? ''),
            'homepage'=>esc_url_raw($data['homepage'] ?? SPBM_AUTHOR_URL),
            'requires'=>sanitize_text_field($data['requires'] ?? '6.0'),
            'tested'=>sanitize_text_field($data['tested'] ?? ''),
            'description'=>wp_kses_post($data['description'] ?? 'Modern popup campaign manager with private license control.'),
            'changelog'=>wp_kses_post($data['changelog'] ?? 'Bug fixes and improvements.'),
            'last_checked'=>current_time('mysql'),
        ];
        set_transient('spbm_update_info',$clean,6*HOUR_IN_SECONDS);
        return $clean;
    }

    private function update_info(){ return $this->fetch_update_info(false); }

    public function check($transient){
        if(empty($transient->checked[SPBM_BASENAME])) return $transient;
        $license=$this->license->get_status(false);
        if(empty($license['valid'])) return $transient;
        $info=$this->update_info();
        if(empty($info['version']) || empty($info['download_url'])) return $transient;
        if(version_compare(SPBM_VERSION, sanitize_text_field($info['version']), '<')){
            $o=new stdClass();
            $o->slug=SPBM_SLUG;
            $o->plugin=SPBM_BASENAME;
            $o->new_version=sanitize_text_field($info['version']);
            $o->url=esc_url_raw($info['homepage'] ?? SPBM_AUTHOR_URL);
            $o->package=esc_url_raw($info['download_url']);
            $o->tested=sanitize_text_field($info['tested']??'');
            $o->requires=sanitize_text_field($info['requires']??'');
            $transient->response[SPBM_BASENAME]=$o;
        }
        return $transient;
    }

    public function info($result,$action,$args){
        if($action!=='plugin_information' || empty($args->slug) || $args->slug!==SPBM_SLUG) return $result;
        $s=spbm_get_settings(); $info=$this->update_info();
        $o=new stdClass();
        $o->name=SPBM_PLUGIN_NAME; $o->slug=SPBM_SLUG; $o->version=$info['version']??SPBM_VERSION;
        $o->author='<a href="'.esc_url(SPBM_AUTHOR_URL).'" target="_blank">'.esc_html(SPBM_AUTHOR_NAME).'</a>';
        $o->homepage=esc_url($s['view_details_url'] ?: ($info['homepage'] ?? SPBM_AUTHOR_URL));
        $o->requires=$info['requires']??'6.0'; $o->tested=$info['tested']??'6.8'; $o->download_link=$info['download_url']??'';
        $o->sections=['description'=>wp_kses_post($info['description']??'Modern popup campaign manager with Google Apps Script license control.'),'changelog'=>wp_kses_post($info['changelog']??'Performance, targeting, analytics, and UI improvements.')];
        return $o;
    }
}
