<?php
if (!defined('ABSPATH')) exit;
class SPBM_Admin {
    private $license;
    public function __construct($license) {
        $this->license=$license;
        add_action('admin_menu',[$this,'menu']);
        add_action('admin_init',[$this,'register_settings']);
        add_action('admin_enqueue_scripts',[$this,'assets']);
        add_action('admin_notices',[$this,'notice']);
        add_action('admin_post_spbm_activate_license',[$this,'activate_license']);
        add_filter('plugin_row_meta',[$this,'plugin_meta'],10,2);
    }
    public function menu(){
        add_menu_page('Smart Popup','Smart Popup','manage_options','spbm-settings',[$this,'settings_page'],'dashicons-megaphone',56);
        add_submenu_page('spbm-settings','Dashboard','Dashboard','manage_options','spbm-settings',[$this,'settings_page']);
        add_submenu_page('spbm-settings','License','License','manage_options','spbm-license',[$this,'license_page']);
        add_submenu_page('spbm-settings','Analytics','Analytics','manage_options','spbm-analytics',[$this,'analytics_page']);
        add_submenu_page('spbm-settings','Updates','Updates','manage_options','spbm-updates',[$this,'updates_page']);
    }
    public function register_settings(){ register_setting('spbm_settings_group','spbm_settings',[$this,'sanitize']); }
    public function sanitize($input){
        delete_transient('spbm_license_cache'); $d=spbm_default_settings(); $old=spbm_get_settings();
        $api = esc_url_raw($input['license_api_url'] ?? ($input['license_csv_url'] ?? $old['license_api_url']));
        return [
            'license_key'=>sanitize_text_field($input['license_key'] ?? $old['license_key']),
            'license_api_url'=>$api,
            'license_csv_url'=>$api,
            'license_cache_hours'=>max(1,absint($input['license_cache_hours'] ?? $d['license_cache_hours'])),
            'license_hide_credentials'=>!empty($input['license_hide_credentials'])?'1':'0',
            'license_domain_override'=>spbm_normalize_domain($input['license_domain_override'] ?? $old['license_domain_override'] ?? ''),
            'update_json_url'=>esc_url_raw($input['update_json_url'] ?? $old['update_json_url']),
            'brand_color'=>sanitize_hex_color($input['brand_color'] ?? $d['brand_color']) ?: $d['brand_color'],
            'accent_color'=>sanitize_hex_color($input['accent_color'] ?? $d['accent_color']) ?: $d['accent_color'],
            'default_interval'=>max(0,absint($input['default_interval'] ?? $d['default_interval'])),
            'enable_analytics'=>!empty($input['enable_analytics'])?'1':'0',
            'respect_reduced_motion'=>!empty($input['respect_reduced_motion'])?'1':'0',
            'view_details_url'=>esc_url_raw($input['view_details_url'] ?? $old['view_details_url'])
        ];
    }

    public function activate_license(){
        if(!current_user_can('manage_options')) wp_die('Permission denied.');
        check_admin_referer('spbm_activate_license');
        $old=spbm_get_settings();
        $key=trim(sanitize_text_field(wp_unslash($_POST['license_key'] ?? '')), " \t\n\r\0\x0B\"'");
        $posted_api=esc_url_raw(trim((string)wp_unslash($_POST['license_api_url'] ?? ''), " \t\n\r\0\x0B\"'"));
        $api=$posted_api ?: esc_url_raw($old['license_api_url'] ?? '');
        $cache=max(1,absint($_POST['license_cache_hours'] ?? $old['license_cache_hours']));
        $domain_override=spbm_normalize_domain(wp_unslash($_POST['license_domain_override'] ?? ''));
        delete_transient('spbm_license_cache');
        if ($key === '' || $api === '') {
            wp_safe_redirect(add_query_arg(['page'=>'spbm-license','spbm_activation'=>'failed','spbm_status'=>'missing_fields'], admin_url('admin.php')));
            exit;
        }
        $old['license_key']=$key;
        $old['license_api_url']=$api;
        $old['license_csv_url']='';
        $old['license_cache_hours']=$cache;
        $old['license_hide_credentials']='1';
        $old['license_domain_override']=$domain_override;
        update_option('spbm_settings',$old,false);
        $status=$this->license->get_status(true);
        $arg=!empty($status['valid'])?'activated':'failed';
        wp_safe_redirect(add_query_arg(['page'=>'spbm-license','spbm_activation'=>$arg,'spbm_status'=>rawurlencode($status['status'] ?? ''),'spbm_msg'=>rawurlencode($status['message'] ?? '')], admin_url('admin.php')));
        exit;
    }

    public function assets($hook){ if(strpos((string)$hook,'spbm')!==false || get_post_type()==='spbm_popup'){ wp_enqueue_style('spbm-admin',SPBM_URL.'assets/css/admin.css',[],SPBM_VERSION); wp_enqueue_script('spbm-admin',SPBM_URL.'assets/js/admin.js',[],SPBM_VERSION,true); add_thickbox(); } }
    private function header($title){ echo '<div class="wrap spbm-wrap spbm-v2"><div class="spbm-hero"><div><span class="spbm-kicker">Campaign OS</span><h1>'.esc_html($title).'</h1><p>Modern popup campaigns, private license control and update delivery for WordPress/WooCommerce.</p></div><div class="spbm-version">v'.esc_html(SPBM_VERSION).'</div></div>'; }
    public function settings_page(){ $s=spbm_get_settings(); $this->header('Smart Popup Banner Manager'); ?>
        <div class="spbm-shell">
            <div class="spbm-panel"><h2>Design System</h2><form method="post" action="options.php"><?php settings_fields('spbm_settings_group'); ?>
                <div class="spbm-grid"><label><span>Brand Color</span><input type="color" name="spbm_settings[brand_color]" value="<?php echo esc_attr($s['brand_color']);?>"></label><label><span>Accent Color</span><input type="color" name="spbm_settings[accent_color]" value="<?php echo esc_attr($s['accent_color']);?>"></label><label><span>Default Frequency</span><input type="number" name="spbm_settings[default_interval]" value="<?php echo esc_attr($s['default_interval']);?>"><small>Minutes per visitor/IP</small></label></div>
                <p><label><strong>Update JSON URL</strong><input class="widefat" type="url" name="spbm_settings[update_json_url]" value="<?php echo esc_attr($s['update_json_url']);?>" placeholder="https://raw.githubusercontent.com/.../update.json"></label></p>
                <p><label><strong>View Details URL</strong><input class="widefat" type="url" name="spbm_settings[view_details_url]" value="<?php echo esc_attr($s['view_details_url']);?>" placeholder="Plugin details page URL"></label></p>
                <div class="spbm-toggles"><label><input type="checkbox" name="spbm_settings[enable_analytics]" value="1" <?php checked($s['enable_analytics'],'1');?>> Local analytics events</label><label><input type="checkbox" name="spbm_settings[respect_reduced_motion]" value="1" <?php checked($s['respect_reduced_motion'],'1');?>> Respect reduced-motion</label></div>
                <?php /* License credentials are intentionally not printed on non-license pages. */ submit_button('Save Settings','primary spbm-primary'); ?>
            </form></div>
            <div class="spbm-panel spbm-stats"><h2>Enterprise-ready Features</h2><ul><li>Private Apps Script license API</li><li>Domain-bound activation</li><li>Image and HTML campaign modes</li><li>Scheduling, priority and targeting</li><li>Fast cached frontend rendering</li></ul></div>
        </div></div><?php }
    public function license_page(){
        if (isset($_GET['spbm_deactivate']) && check_admin_referer('spbm_deactivate')) { $this->license->deactivate_local(); echo '<div class="notice notice-success"><p>Local license removed and remote activation release was requested. You can activate again with a new key.</p></div>'; }
        if (isset($_GET['spbm_reset_license']) && check_admin_referer('spbm_reset_license')) { $this->license->reset_local(); echo '<div class="notice notice-success"><p>License fields reset. Add a fresh license key below.</p></div>'; }
        if (isset($_GET['spbm_activation']) && $_GET['spbm_activation']==='activated') { echo '<div class="notice notice-success"><p>License activated successfully.</p></div>'; }
        if (isset($_GET['spbm_activation']) && $_GET['spbm_activation']==='failed') { $m = !empty($_GET['spbm_msg']) ? sanitize_text_field(wp_unslash($_GET['spbm_msg'])) : 'License activation failed. Check License API URL, license key, domain row, status active, and Apps Script deployment.'; $st = !empty($_GET['spbm_status']) ? sanitize_text_field(wp_unslash($_GET['spbm_status'])) : 'failed'; echo '<div class="notice notice-error"><p><strong>License activation failed:</strong> '.esc_html($m).' <code>'.esc_html($st).'</code></p></div>'; }
        $s=spbm_get_settings();
        $has_saved_credentials = !empty($s['license_key']) && (!empty($s['license_api_url']) || !empty($s['license_csv_url']));
        // Realtime activation check: if credentials exist but the license is not active yet,
        // do not reuse an old inactive cache. This supports installing first and adding the Sheet row later.
        $status=$this->license->get_status(isset($_GET['force_check']) || $has_saved_credentials);
        $active=!empty($status['valid']); $masked=spbm_mask_key($s['license_key']);
        $this->header('Theme license'); ?>
        <div class="spbm-license-card <?php echo $active?'is-active':'is-inactive'; ?>">
            <div class="spbm-license-art"><div class="spbm-orb"></div><div class="spbm-key">🔑</div><div class="spbm-person">✓</div></div>
            <div class="spbm-license-content">
                <?php if($active): ?>
                    <h2>Thank you for activation.</h2><p>You can receive product updates and use Smart Popup campaigns on this domain.</p>
                    <div class="spbm-countdown" data-expiry="<?php echo esc_attr($status['expires_ts'] ?? spbm_parse_expiry_timestamp($status['expires'])); ?>"><div><strong data-days>--</strong><span>Days</span></div><div><strong data-hours>--</strong><span>Hours</span></div><div><strong data-minutes>--</strong><span>Minutes</span></div><div><strong data-seconds>--</strong><span>Seconds</span></div></div><div class="spbm-license-meta"><span>Domain: <b><?php echo esc_html(spbm_license_domain());?></b></span><span>Expires: <b><?php echo esc_html(spbm_format_expiry_date($status['expires']));?></b></span><span>Plan: <b><?php echo esc_html($status['plan'] ?: 'yearly');?></b></span></div>
                    <p class="spbm-muted">License credentials are hidden after activation. Active licenses are cached for performance; Force Check syncs immediately after changing expiry/status in your private license sheet.</p>
                    <p><a class="button spbm-danger" href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=spbm-license&spbm_deactivate=1'),'spbm_deactivate'));?>">Remove local license</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=spbm-license&force_check=1'));?>">Force Check</a> <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=spbm-license&spbm_reset_license=1'),'spbm_reset_license'));?>">Reset fields</a></p>
                <?php else: ?>
                    <h2>Activate your license</h2><p>Status: <span class="spbm-badge"><?php echo esc_html($status['status']);?></span> <?php echo esc_html($status['message']);?></p>
                    <p class="spbm-muted">Paste the private Apps Script Web App URL and license key. Saved credentials are never printed back on this screen.</p>
                    <div class="spbm-license-meta"><span>Detected domain: <b><?php echo esc_html(spbm_current_domain());?></b></span><span>License domain: <b><?php echo esc_html(spbm_license_domain());?></b></span><span>Last check: <b><?php echo esc_html($status['checked_at'] ?? 'N/A');?></b></span><span>API saved: <b><?php echo !empty($s['license_api_url']) ? 'Yes' : 'No'; ?></b></span><span>Source: <b><?php echo esc_html($status['source'] ?? 'N/A');?></b></span></div>
                    <div class="spbm-license-meta"><span>HTTP: <b><?php echo esc_html($status['http_code'] ?: 'N/A');?></b></span><span>Detected status: <b><?php echo esc_html($status['raw_status'] ?: $status['status']);?></b></span><span>Expires: <b><?php echo esc_html(!empty($status['expires']) ? spbm_format_expiry_date($status['expires']) : 'N/A');?></b></span></div>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="spbm-secure-license-form"><?php wp_nonce_field('spbm_activate_license'); ?><input type="hidden" name="action" value="spbm_activate_license">
                        <p><label><strong>Licensed Domain</strong><input class="widefat" type="text" name="license_domain_override" value="<?php echo esc_attr(spbm_license_domain()); ?>" placeholder="example.com" autocomplete="off" spellcheck="false"></label><small>This must match the Domain column in your private license sheet. Use this when WordPress detects a temporary/server domain.</small></p>
                        <p><label><strong>License API URL</strong><input class="widefat" type="password" name="license_api_url" value="" placeholder="https://script.google.com/macros/s/...../exec" autocomplete="new-password" spellcheck="false"></label><small>Use the deployed Web App <b>/exec</b> URL, not the Apps Script editor or /dev URL.</small></p>
                        <p><label><strong>License Key</strong><input class="widefat" type="password" name="license_key" value="" placeholder="Paste license key" autocomplete="new-password" spellcheck="false"></label></p>
                        <p><label><strong>Cache Hours</strong><input type="number" min="1" name="license_cache_hours" value="<?php echo esc_attr($s['license_cache_hours']);?>"></label></p>
                        <?php submit_button('Activate License','primary spbm-primary'); ?>
                    </form>
                    <?php if(!empty($s['license_key']) || !empty($s['license_api_url']) || !empty($s['license_csv_url'])): ?>
                        <p><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=spbm-license&spbm_reset_license=1'),'spbm_reset_license'));?>">Clear stored license</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=spbm-license&force_check=1'));?>">Force Check</a></p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        </div><?php }
    private function hidden_fields($s,$keys){ foreach($keys as $k){ echo '<input type="hidden" name="spbm_settings['.esc_attr($k).']" value="'.esc_attr($s[$k] ?? '').'">'; } }
    public function analytics_page(){
        if(isset($_GET['spbm_cleared'])) echo '<div class="notice notice-success"><p>Analytics data cleared.</p></div>';
        $days = max(1, absint($_GET['days'] ?? 30));
        $totals = SPBM_Analytics::totals($days);
        $rows = SPBM_Analytics::campaign_rows($days);
        $daily = SPBM_Analytics::daily_rows(min($days,30));
        $this->header('Analytics Dashboard'); ?>
        <div class="spbm-shell">
            <div class="spbm-panel spbm-kpi-grid">
                <div class="spbm-kpi"><span>Views</span><strong><?php echo esc_html(number_format_i18n($totals['view'])); ?></strong></div>
                <div class="spbm-kpi"><span>Clicks</span><strong><?php echo esc_html(number_format_i18n($totals['click'])); ?></strong></div>
                <div class="spbm-kpi"><span>CTR</span><strong><?php echo esc_html($totals['ctr']); ?>%</strong></div>
                <div class="spbm-kpi"><span>Close Rate</span><strong><?php echo esc_html($totals['close_rate']); ?>%</strong></div>
            </div>
            <div class="spbm-panel">
                <form method="get" class="spbm-inline-tools"><input type="hidden" name="page" value="spbm-analytics"><label>Range <select name="days"><option value="7" <?php selected($days,7); ?>>7 days</option><option value="30" <?php selected($days,30); ?>>30 days</option><option value="90" <?php selected($days,90); ?>>90 days</option></select></label><button class="button">Apply</button><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=spbm_export_analytics&days='.$days),'spbm_export_analytics')); ?>">Export CSV</a><a class="button spbm-danger" onclick="return confirm('Clear all analytics events?')" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=spbm_clear_analytics'),'spbm_clear_analytics')); ?>">Clear Data</a></form>
                <h2>Campaign performance</h2>
                <table class="widefat striped"><thead><tr><th>Campaign</th><th>Views</th><th>Clicks</th><th>CTR</th><th>Closes</th><th>Last Event</th></tr></thead><tbody>
                <?php if(!$rows): ?><tr><td colspan="6">No analytics yet. Open the frontend popup once and click/close it to generate events.</td></tr><?php endif; ?>
                <?php foreach($rows as $r): $views=(int)$r->views; $clicks=(int)$r->clicks; ?>
                    <tr><td><a href="<?php echo esc_url(get_edit_post_link($r->popup_id)); ?>"><?php echo esc_html(get_the_title($r->popup_id) ?: ('Popup #'.$r->popup_id)); ?></a></td><td><?php echo esc_html(number_format_i18n($views)); ?></td><td><?php echo esc_html(number_format_i18n($clicks)); ?></td><td><?php echo esc_html($views?round($clicks/$views*100,2):0); ?>%</td><td><?php echo esc_html(number_format_i18n((int)$r->closes)); ?></td><td><?php echo esc_html($r->last_event); ?></td></tr>
                <?php endforeach; ?></tbody></table>
            </div>
            <div class="spbm-panel"><h2>Daily trend</h2><div class="spbm-bars">
                <?php foreach($daily as $d): $h=min(100,max(4,(int)$d->views)); ?><div class="spbm-bar" title="<?php echo esc_attr($d->day.' | Views: '.$d->views.' | Clicks: '.$d->clicks); ?>"><span style="height:<?php echo esc_attr($h); ?>px"></span><em><?php echo esc_html(date_i18n('M j', strtotime($d->day))); ?></em></div><?php endforeach; ?>
                <?php if(!$daily): ?><p>No daily data yet.</p><?php endif; ?>
            </div></div>
        </div></div><?php }

    public function updates_page(){
        $s=spbm_get_settings();
        delete_transient('spbm_update_info');
        $license=$this->license->get_status(true);
        $checker = class_exists('SPBM_Update_Checker') ? new SPBM_Update_Checker($this->license, false) : null;
        $info = $checker ? $checker->fetch_update_info(true) : [];
        $this->header('Update Center'); ?>
        <div class="spbm-shell"><div class="spbm-panel">
            <h2>Private Update System</h2>
            <p>Use GitHub Release or any direct ZIP URL for plugin package delivery. Update notices appear in WordPress Plugins when license is active and the JSON version is newer than installed version.</p>
            <table class="widefat striped"><tbody>
                <tr><th>Installed Version</th><td><?php echo esc_html(SPBM_VERSION); ?></td></tr>
                <tr><th>Latest Version</th><td><?php echo esc_html($info['version'] ?? 'Not detected'); ?></td></tr>
                <tr><th>License</th><td><?php echo !empty($license['valid']) ? '<span class="spbm-ok">Active</span>' : '<span class="spbm-bad">Inactive</span>'; ?></td></tr>
                <tr><th>Update JSON URL</th><td><?php echo esc_html($s['update_json_url'] ?: 'Not configured'); ?></td></tr>
                <tr><th>Download URL</th><td><?php echo esc_html($info['download_url'] ?? 'Not detected'); ?></td></tr>
            </tbody></table>
            <p><a class="button button-primary" href="<?php echo esc_url(admin_url('update-core.php?force-check=1')); ?>">Check WordPress Updates</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=spbm-settings')); ?>">Edit Update JSON URL</a></p>
        </div><div class="spbm-panel"><h2>update.json example</h2><pre>{
  "version": "2.6.1",
  "download_url": "https://github.com/yourname/yourrepo/releases/download/v2.6.1/smart-popup-banner-manager.zip",
  "homepage": "https://your-domain.com/plugin-details.html",
  "requires": "6.0",
  "tested": "6.8",
  "description": "Smart Popup Banner Manager update.",
  "changelog": "Security, analytics and UI improvements."
}</pre></div></div></div><?php }

    public function notice(){ if(!current_user_can('manage_options'))return; $screen=get_current_screen(); if($screen && strpos($screen->id,'spbm')!==false)return; $st=$this->license->get_status(false); if(empty($st['valid'])) echo '<div class="notice notice-warning"><p><strong>Smart Popup Banner Manager:</strong> '.esc_html($st['message']).'</p></div>'; }
    public function plugin_meta($links,$file){ if($file===SPBM_BASENAME){ $links[]='By <a href="'.esc_url(SPBM_AUTHOR_URL).'" target="_blank">'.esc_html(SPBM_AUTHOR_NAME).'</a>'; $details=spbm_get_settings()['view_details_url'] ?: network_admin_url('plugin-install.php?tab=plugin-information&plugin='.SPBM_SLUG.'&TB_iframe=true&width=772&height=620'); $links[]='<a href="'.esc_url($details).'" class="'.(strpos($details,'plugin-install.php')!==false?'thickbox open-plugin-details-modal':'').'">View details</a>'; } return $links; }
}
